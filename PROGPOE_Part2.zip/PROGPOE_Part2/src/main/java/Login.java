import java.util.Scanner;

public class Login {

    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhoneNumber;

    public Login() {}

    public Login(String firstName, String lastName,
                 String username, String password,
                 String cellPhoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    // ─────────────────────────────────────────────
    // checkUserName()
    // ─────────────────────────────────────────────
    public boolean checkUserName() {
        if (username == null) return false;
        int underscoreCount = 0;
        for (char c : username.toCharArray()) {
            if (c == '_') underscoreCount++;
        }
        return underscoreCount == 1 && username.length() <= 5;
    }

    // ─────────────────────────────────────────────
    // checkPasswordComplexity()
    // ─────────────────────────────────────────────
    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) return false;
        boolean hasUpper = false, hasDigit = false, hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            if (Character.isDigit(c))     hasDigit = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasUpper && hasDigit && hasSpecial;
    }

    // ─────────────────────────────────────────────
    // checkCellPhoneNumber()
    // ─────────────────────────────────────────────
    public boolean checkCellPhoneNumber() {
        if (cellPhoneNumber == null) return false;
        return cellPhoneNumber.matches("^\\+27\\d{9}$");
    }

    // ─────────────────────────────────────────────
    // registerUser()
    // ─────────────────────────────────────────────
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; "
                 + "must contain one underscore and be no more than five characters.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; "
                 + "must contain at least eight characters, "
                 + "a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted; "
                 + "must start with +27 followed by 9 digits.";
        }
        return "Registration successful.";
    }

    // ─────────────────────────────────────────────
    // loginUser()
    // ─────────────────────────────────────────────
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }

    // ─────────────────────────────────────────────
    // returnLoginStatus()
    // ─────────────────────────────────────────────
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // ─────────────────────────────────────────────
    // Getters
    // ─────────────────────────────────────────────
    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName; }

    // ─────────────────────────────────────────────
    // MAIN — QuickChat Application
    // ─────────────────────────────────────────────
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // ── Registration ──
        System.out.println("=== Chat Registration ===");
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter username (one _ required, max 5 chars): ");
        String username = scanner.nextLine();

        System.out.print("Enter password (8+ chars, 1 capital, 1 number, 1 special): ");
        String password = scanner.nextLine();

        System.out.print("Enter cell phone (e.g. +27831234567): ");
        String cellPhone = scanner.nextLine();

        Login user = new Login(firstName, lastName, username, password, cellPhone);
        String regResult = user.registerUser();
        System.out.println("\nRegistration Result: " + regResult);

        if (!regResult.equals("Registration successful.")) {
            System.out.println("Registration failed. Exiting.");
            return;
        }

        // ── Login ──
        System.out.println("\n=== Chat Login ===");
        System.out.print("Username: ");
        String loginUser = scanner.nextLine();
        System.out.print("Password: ");
        String loginPass = scanner.nextLine();

        String loginStatus = user.returnLoginStatus(loginUser, loginPass);
        System.out.println("\n" + loginStatus);

        if (!user.loginUser(loginUser, loginPass)) {
            System.out.println("Login failed. Exiting.");
            return;
        }

        // ── QuickChat Menu (only accessible after successful login) ──
        System.out.println("\nWelcome to QuickChat.");

        System.out.print("\nHow many messages do you wish to send? ");
        int numMessages;
        try {
            numMessages = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number. Exiting.");
            return;
        }

        boolean running = true;
        while (running) {
            System.out.println("\n=== QuickChat Menu ===");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");
            String menuChoice = scanner.nextLine().trim();

            switch (menuChoice) {
                case "1":
                    // Send messages up to the user-defined limit
                    for (int i = 0; i < numMessages; i++) {
                        System.out.println("\n--- Message " + (i + 1) + " of " + numMessages + " ---");

                        // Recipient
                        String recipient;
                        while (true) {
                            System.out.print("Enter recipient cell number (with international code, max 10 chars): ");
                            recipient = scanner.nextLine().trim();
                            Message tempMsg = new Message();
                            tempMsg.setRecipient(recipient);
                            String cellCheck = tempMsg.checkRecipientCell();
                            if (cellCheck.equals("Cell phone number successfully captured.")) {
                                System.out.println(cellCheck);
                                break;
                            } else {
                                System.out.println(cellCheck);
                            }
                        }

                        // Message text
                        String messageText;
                        while (true) {
                            System.out.print("Enter message (max 250 characters): ");
                            messageText = scanner.nextLine();
                            String validation = Message.validateMessage(messageText);
                            if (validation.equals("Message ready to send.")) {
                                break;
                            } else {
                                System.out.println(validation);
                            }
                        }

                        // Create the message (msgCount starts at 0, increments)
                        int msgNumber = Message.returnTotalMessagess();
                        Message msg = new Message(recipient, messageText, msgNumber);

                        // Display message details
                        System.out.println("\n--- Message Details ---");
                        System.out.println("Message ID:   " + msg.getMessageID());
                        System.out.println("Message Hash: " + msg.getMessageHash());
                        System.out.println("Recipient:    " + msg.getRecipient());
                        System.out.println("Message:      " + msg.getMessageText());

                        // Send / Disregard / Store
                        String result = msg.SentMessage();
                        System.out.println(result);
                    }

                    System.out.println("\nTotal messages sent: " + Message.returnTotalMessagess());
                    break;

                case "2":
                    System.out.println("Coming Soon.");
                    break;

                case "3":
                    running = false;
                    System.out.println("Thank you for using QuickChat. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid option. Please choose 1, 2, or 3.");
            }
        }

        scanner.close();
    }
}
